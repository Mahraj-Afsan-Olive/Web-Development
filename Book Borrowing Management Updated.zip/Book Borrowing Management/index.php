<!DOCTYPE html>
<html>

<head>
 <title>Borrow Book Anytime!</title>
 <link rel="stylesheet" href="style.css">  
</head>

<body>
    <img src="ID.PNG" alt="sorry" class="center">
    <h1>Book Borrowing Management</h1>
    
    <div class="container">
        <div class="left">
            <div class="leftbox">
                <div class="box6"></div>
            </div>
        </div> 
        <div class="middle">
            <div class="first">
                <div class="box1"></div>
                <div class="box1"></div>
            </div>
            <div class="second">
                <div class="box2"></div>
                <div class="box2"></div>
                <div class="box2"></div>
            </div>
            <div class="third">
                <div class="box3"></div>
            </div>
            <div class="fourth">
                <div class="box4">
                    <h4>Borrow Form</h4>
                    <form action="process.php" method="post"class=center>
                       <br><input type="text" id="name" name="name" placeholder="Enter your Name"><br>
                       <input type="text" id="idnum" name="idnum" placeholder="Student ID"><br>
                       <input type="email" id="mail" name="mail" placeholder="Student e-mail"><br>
                        <br>
                        <label for="books">Choose a Book Title:</label><br>
                         <select name="book" id="book">
                          <option value="select">select</option>
                           <option value="book1">Murder on the Orient Express</option>
                           <option value="book2">The Hound of the Baskervilles</option>
                           <option value="book3">The Maltese Falcon</option>
                           <option value="book4">The Big Sleep</option>
                           <option value="book5">The Name of the Rose</option>
                           <option value="book6">In the Woods</option>
                           <option value="book7">The Girl with the Dragon Tattoo</option>
                           <option value="book8">The Silence of the Lambs</option>
                           <option value="book9">Still Life</option>
                           <option value="book10">Motherless Brooklyn</option>
                         </select><br><br>
                         <label for="borrow">Borrow Date:</label>
                         <input type="date" id="borrow_date" name="borrow_date"/><br><br>
                         <input type="number" id="token" name="token"><br><br>
                         <label for="return">Return Date:</label>
                         <input type="date" id="return_date" name="return_date"/><br><br>
                         <input type="number" id="fees" name="fees"><br><br>
                       <input type="submit">
                    </form>
                </div>
                <div class="box5"></div>
            </div>
        </div>
        <div class="right">
            <div class="rightbox">
                <div class="box7"></div>
            </div>
        </div>
    </div>
    
</body>

</html>
