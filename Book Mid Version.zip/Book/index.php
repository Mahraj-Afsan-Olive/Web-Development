<!DOCTYPE html>
<html>

<head>
    <title>Borrow Book Anytime!</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <img src="ID.PNG" alt="sorry" class="center">
    <h1>Book Borrowing Management</h1>

    <div class="container">
        <div class="left">
            <div class="leftbox">
                <div class="box6"></div>
            </div>
        </div>
        <div class="middle">
            <div class="first">
                <div class="box1"></div>
                <div class="box1"></div>
            </div>
            <div class="second">
                <div class="box2"></div>
                <div class="box2"></div>
                <div class="box2"></div>
            </div>
            <div class="third">
                <div class="box3"></div>
            </div>
            <div class="fourth">
                <div class="box4">
                    <h4>Borrow Form</h4>
                    <!-- Display errors -->
                    <?php
                    if (!empty($_GET['errors'])) {
                        $errors = explode('|', $_GET['errors']);
                        foreach ($errors as $error) {
                            echo "<p style='color:red;'>$error</p>";
                        }
                    }
                    ?>
                    
                    <form action="process.php" method="post" class="center">
                        <input type="text" id="name" name="name" placeholder="Enter your Name" required><br>
                        <input type="text" id="idnum" name="idnum" placeholder="Student ID" required><br>
                        <input type="email" id="mail" name="mail" placeholder="Student e-mail" required><br>
                        <label for="book">Choose a Book Title:</label><br>
                        <select name="book" id="book" required>
                            <option value="select">Select</option>
                            <option value="Murder on the Orient Express">Murder on the Orient Express</option>
                            <option value="The Hound of the Baskervilles">The Hound of the Baskervilles</option>
                            <option value="The Maltese Falcon">The Maltese Falcon</option>
                            <option value="The Big Sleep">The Big Sleep</option>
                            <option value="The Name of the Rose">The Name of the Rose</option>
                            <option value="In the Woods">In the Woods</option>
                            <option value="The Girl with the Dragon Tattoo">The Girl with the Dragon Tattoo</option>
                            <option value="The Silence of the Lambs">The Silence of the Lambs</option>
                            <option value="Still Life">Still Life</option>
                            <option value="Motherless Brooklyn">Motherless Brooklyn</option>
                        </select><br><br>
                        <label for="borrow_date">Borrow Date:</label>
                        <input type="date" id="borrow_date" name="borrow_date" required><br>
                        <label for="return_date">Return Date:</label>
                        <input type="date" id="return_date" name="return_date" required><br>
                        <label for="token">Token Number:</label>
                        <input type="number" id="token" name="token" required><br>
                        <label for="fees">Fees:</label>
                        <input type="number" id="fees" name="fees" required><br><br>
                        <input type="submit" value="Submit">
                    </form>
                </div>
                <div class="box5"></div>
            </div>
        </div>
        <div class="right">
            <div class="rightbox">
                <div class="box7"></div>
            </div>
        </div>
    </div>

</body>

</html>