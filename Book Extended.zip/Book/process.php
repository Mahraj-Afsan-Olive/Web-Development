<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $id = trim($_POST["idnum"]);
    $email = trim($_POST["mail"]);
    $book = trim($_POST["book"]);
    $borrow_date = $_POST["borrow_date"];
    $return_date = $_POST["return_date"];
    $token = trim($_POST["token"]);
    $fees = trim($_POST["fees"]);

    $errors = [];

    if (empty($name) || !preg_match("/^[a-zA-Z. ]+$/", $name)) {
        $errors[] = "Name can only contain letters and dots.";
    }

    if (empty($id) || !preg_match("/^\\d{2}-\\d{5}-\\d$/", $id)) {
        $errors[] = "ID must follow the format XX-XXXXX-X.";
    }

    if (empty($email) || !preg_match("/^{$id}@student\\.aiub\\.edu$/", $email)) {
        $errors[] = "Email must follow the format XX-XXXXX-X@student.aiub.edu.";
    }

    if (empty($book) || $book === "select") {
        $errors[] = "You must select a book title.";
    }

    $book_cookie = preg_replace('/[^a-zA-Z0-9_]/', '', strtolower($book)); 

    if (isset($_COOKIE[$book_cookie])) {
        $errors[] = "The book '$book' is currently borrowed by " . htmlspecialchars($_COOKIE[$book_cookie]) . ". Please wait until it is returned.";
    }

    if (empty($borrow_date) || empty($return_date)) {
        $errors[] = "Borrow and Return dates are required.";
    } else {
        $borrow_time = strtotime($borrow_date);
        $return_time = strtotime($return_date);
        $difference_in_days = ($return_time - $borrow_time) / (60 * 60 * 24);

        if ($difference_in_days <= 0) {
            $errors[] = "Return date must be later than borrow date.";
        }
        if ($difference_in_days > 10) {
            $errors[] = "Return date must be within 10 days of borrow date.";
        }
    }

    if (empty($token) || !is_numeric($token)) {
        $errors[] = "Token number must be a valid number.";
    }
    if (empty($fees) || !is_numeric($fees)) {
        $errors[] = "Fees must be a valid number.";
    }

    if (!empty($errors)) {
        $error_string = implode('|', $errors);
        header("Location: index.php?errors=$error_string");
        exit;
    }

    $_SESSION["name"] = $name;
    $_SESSION["idnum"] = $id;
    $_SESSION["email"] = $email;
    $_SESSION["book"] = $book;
    $_SESSION["borrow_date"] = $borrow_date;
    $_SESSION["return_date"] = $return_date;
    $_SESSION["token"] = $token;
    $_SESSION["fees"] = $fees;

    setcookie($book_cookie, $name, time() + (10 * 24 * 60 * 60), '/');

    header("Location: receipt.php");
    exit;
}
?>
