<!DOCTYPE html>
<html lang="en">
<head>
    <title>Borrow Receipt</title>
    <link rel="stylesheet" href="receipt_style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
</head>
<body>
    <div class="receipt" id="receipt">
        <h2>Book Borrowing Receipt</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_POST["name"]); ?></p>
        <p><strong>Student ID:</strong> <?php echo htmlspecialchars($_POST["idnum"]); ?></p>
        <p><strong>Student Email:</strong> <?php echo htmlspecialchars($_POST["mail"]); ?></p>
        <p><strong>Book Title:</strong> <?php echo htmlspecialchars($_POST["book"]); ?></p>
        <p><strong>Borrow Date:</strong> <?php echo htmlspecialchars($_POST["borrow_date"]); ?></p>
        <p><strong>Token No:</strong> <?php echo htmlspecialchars($_POST["token"]); ?></p>
        <p><strong>Return Date:</strong> <?php echo htmlspecialchars($_POST["return_date"]); ?></p>
        <p><strong>Fees:</strong> <?php echo htmlspecialchars($_POST["fees"]); ?> Tk</p>
        <canvas id="qr-code"></canvas><br>   
    </div>
    
    <div class="button-container">
        <button onclick="downloadReceipt()">Download Receipt</button>
    </div>
    

    <script>
        function generateQRCode() {
            const receiptData = `
                Name: <?php echo htmlspecialchars($_POST["name"]); ?>
                Student ID: <?php echo htmlspecialchars($_POST["idnum"]); ?>
                Student Email: <?php echo htmlspecialchars($_POST["mail"]); ?>
                Book Title: <?php echo htmlspecialchars($_POST["book"]); ?>
                Borrow Date: <?php echo htmlspecialchars($_POST["borrow_date"]); ?>
                Token No: <?php echo htmlspecialchars($_POST["token"]); ?>
                Return Date: <?php echo htmlspecialchars($_POST["return_date"]); ?>
                Fees: <?php echo htmlspecialchars($_POST["fees"]); ?> Tk
            `;
            const qr = new QRious({
                element: document.getElementById('qr-code'),
                value: receiptData,
                size: 150
            });
        }
        generateQRCode();

        function downloadReceipt() {
            const receipt = document.getElementById("receipt");
            html2canvas(receipt).then(canvas => {
                const link = document.createElement("a");
                link.href = canvas.toDataURL("image/png");
                link.download = "receipt.png";
                link.click();
            });
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</body>
</html>

